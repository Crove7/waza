/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionhospitalaria;

/**
 *
 * @author Alumno
 */
public class Paciente extends Persona{
    
    public Paciente(String DNI, String nombre, String apellido) {
        super(DNI, nombre, apellido);
    }
    
    
    @Override
    public String toString() {
        return "Paciente{" + super.toString() + '}';
    }

       
    
}
