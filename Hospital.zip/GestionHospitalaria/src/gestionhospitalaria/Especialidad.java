/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestionhospitalaria;

/**
 *
 * @author Alumno
 */
public enum Especialidad {
    DENTISTA,
    CARDIOLOGO,
    DERMATOLOGIA;
}
