/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionhospitalaria;

/**
 *
 * @author Alumno
 */
public abstract class Persona {
    private int ID;
    private static int aux=0;
    private String DNI;
    private String nombre;
    private String apellido;

    public Persona(String DNI, String nombre, String apellido) {
        this.ID +=aux;
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        aux++;
    }

    public int getID() {
        return ID;
    }

   
    
    @Override
    public String toString() {
        return "Persona{" + "DNI=" + DNI + ", nombre=" + nombre + ", apellido=" + apellido + '}';
    }
    
    
    
}
