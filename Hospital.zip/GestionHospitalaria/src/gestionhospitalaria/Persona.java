/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionhospitalaria;

/**
 *
 * @author Alumno
 */
public abstract class Persona {
    private static int ID;
    private String DNI;
    private String nombre;
    private String apellido;

    public Persona(String DNI, String nombre, String apellido) {
        this.ID +=1;
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public static int getID() {
        return ID;
    }

    public static void setID(int ID) {
        Persona.ID = ID;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    
    @Override
    public String toString() {
        return "Persona{" + "DNI=" + DNI + ", nombre=" + nombre + ", apellido=" + apellido + '}';
    }
    
    
    
}
