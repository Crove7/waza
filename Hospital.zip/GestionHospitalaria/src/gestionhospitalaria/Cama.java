/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionhospitalaria;

/**
 *
 * @author Alumno
 */
public class Cama {
    private static int codigo;
    private int piso;
    private boolean estado;

    public Cama(int piso) {
        this.codigo +=1 ;
        this.piso = piso;
        this.estado = false;
    }

    public boolean isEstado() {
        return estado;
    }
    
    
    
}
