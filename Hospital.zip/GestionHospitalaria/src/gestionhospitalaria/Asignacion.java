/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionhospitalaria;

import java.util.ArrayList;


public class Asignacion {
    private ArrayList<Medico> medicos= new ArrayList<>();


    
    
    public void CrearReserva(){
        
    }
    
    public void AgregarMedico(Medico medico){
        medicos.add(medico);
    }
    public void EliminarMedico(Medico medico){
        medicos.remove(medico);
    }
    
    public void AsignarMedicoAPaciente(Paciente paciente, Especialidad especialidad){
        for (Medico medico : medicos) {
            if (medico.getEspecialidad()==especialidad) {
                medico.AgregarPaciente(paciente);
            }
        }
    }

    @Override
    public String toString() {
        return "Asignacion{" + "medicos=" + medicos + '}';
    }
    
    
}
