/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionhospitalaria;

import java.util.ArrayList;

public class Medico extends Persona{
    private Especialidad especialidad;
    private ArrayList<Paciente> pacientes= new ArrayList<>();
    
    public Medico(String DNI, String nombre, String apellido,Especialidad especialidad) {
        super(DNI, nombre, apellido);
        this.especialidad= especialidad;
        
    }
    

    
    
    
    public void AgregarPaciente(Paciente paciente){
        pacientes.add(paciente);
    }
    
    public void QuitarPaciente(Paciente paciente){
        if (pacientes.contains(paciente)) {
            pacientes.remove(paciente);
        }else{
            System.out.println("NO EXISTE");
        }
        
    }

    public Especialidad getEspecialidad() {
        return especialidad;
    }

    @Override
    public String toString() {
        return "Medico{" + "especialidad=" + especialidad + ", pacientes=" + pacientes + '}';
    }

   
    
}
