package gestionhospitalaria;

/**
 *
 * @author Alumno
 */
public class GestionHospitalaria {

    
    public static void main(String[] args) {
        
        Paciente paciente1 = new Paciente("123", "Carlos", "Lopez");
        Medico medico1 = new Medico("1234", "Jose", "Jose", Especialidad.DENTISTA);
        Medico medico2 = new Medico("34", "carlo", "pedro", Especialidad.CARDIOLOGO);
        Medico medico3 = new Medico("134", "Martin", "asa", Especialidad.DERMATOLOGIA);
        Asignacion asignador= new Asignacion();
       
        
   
        
        
   
        asignador.AgregarMedico(medico1);
        asignador.AgregarMedico(medico2);
        asignador.AgregarMedico(medico3);
        
        asignador.AsignarMedicoAPaciente(paciente1, Especialidad.CARDIOLOGO);
        System.out.println(medico2);
       
    }
    
}
